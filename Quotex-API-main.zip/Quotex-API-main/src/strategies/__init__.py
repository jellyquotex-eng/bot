"""Strategy Algorithms Package"""
